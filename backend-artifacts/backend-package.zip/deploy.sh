#!/bin/bash
# Simple deployment script for the backend

# Install dependencies
pip install -r requirements.txt

# Run the backend
python app.py
