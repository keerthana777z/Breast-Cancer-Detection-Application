# Breast Cancer Detection Backend

This is the backend for the Breast Cancer Detection Application.

## Important Note About the Model File

The actual model file (`my_model3.h5`) is not included in this package due to size limitations.
You need to provide your own trained model file or use the one from your local repository.

If you have the model file in your local repository:
1. Copy `my_model3.h5` from your local BACKEND folder to this directory
2. Then run the application as described below

## Running the Backend

```bash
# Install dependencies
pip install -r requirements.txt

# Run the application
python app.py
```

The backend will be available at http://localhost:5003
